class Main {
  public static void main(String[] args) {
    int[] coolArray = new int[] {2,8,5,9,0,2,4};
    for(int x =0; x<coolArray.length;x++)
      {
        System.out.print(coolArray[x]);
      }
    System.out.println();
    reverseArray(coolArray);
    for(int x =0; x<coolArray.length;x++)
      {
        System.out.print(coolArray[x]);
      }
    
  }
  public static void reverseArray(int[] array) {
    int first = 0;
    int last = array.length - 1;

    while (first < last) {
        int temp = array[first];
        array[first] = array[last];
        array[last] = temp;
        first++;
        last--;
    }
    System.out.println("The array has been reversed.");
}
}